package com.dbms.triplehao.dao;

import com.dbms.triplehao.entity.RegionStore;

import java.util.List;

public interface RegionStoreDao {
    List<RegionStore> queryRegionStore();
}
